---
name: Warm Editorial Accessibility
colors:
  surface: '#f6fbf5'
  surface-dim: '#d7dbd6'
  surface-bright: '#f6fbf5'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f0f5f0'
  surface-container: '#ebefea'
  surface-container-high: '#e5e9e4'
  surface-container-highest: '#dfe4df'
  on-surface: '#181d1a'
  on-surface-variant: '#414943'
  inverse-surface: '#2c322e'
  inverse-on-surface: '#edf2ed'
  outline: '#717973'
  outline-variant: '#c0c9c1'
  surface-tint: '#3a674f'
  primary: '#14422d'
  on-primary: '#ffffff'
  primary-container: '#2d5a43'
  on-primary-container: '#9fcfb2'
  inverse-primary: '#a1d1b4'
  secondary: '#97472e'
  on-secondary: '#ffffff'
  secondary-container: '#fe997a'
  on-secondary-container: '#772f18'
  tertiary: '#254030'
  on-tertiary: '#ffffff'
  tertiary-container: '#3c5747'
  on-tertiary-container: '#adcbb7'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#bceecf'
  primary-fixed-dim: '#a1d1b4'
  on-primary-fixed: '#002112'
  on-primary-fixed-variant: '#224f39'
  secondary-fixed: '#ffdbd0'
  secondary-fixed-dim: '#ffb59f'
  on-secondary-fixed: '#3a0a00'
  on-secondary-fixed-variant: '#793019'
  tertiary-fixed: '#cbead4'
  tertiary-fixed-dim: '#b0ceb9'
  on-tertiary-fixed: '#052013'
  on-tertiary-fixed-variant: '#324c3d'
  background: '#f6fbf5'
  on-background: '#181d1a'
  surface-variant: '#dfe4df'
typography:
  headline-xl:
    fontFamily: Newsreader
    fontSize: 40px
    fontWeight: '500'
    lineHeight: 48px
    letterSpacing: -0.02em
  headline-xl-mobile:
    fontFamily: Newsreader
    fontSize: 30px
    fontWeight: '500'
    lineHeight: 36px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Newsreader
    fontSize: 32px
    fontWeight: '500'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Newsreader
    fontSize: 24px
    fontWeight: '500'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Newsreader
    fontSize: 22px
    fontWeight: '500'
    lineHeight: 28px
  title-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  title-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 17px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.04em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.25rem
  gutter-tablet: 1.5rem
  gutter-desktop: 2rem
  margin: 1rem
  margin-tablet: 2rem
  margin-desktop: 3rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

The design system is centered on human dignity, unhurried clarity, and natural dialogue between Deaf or hard-of-hearing signers and vocal speakers. It rejects tech-centric tropes such as synthetic glow effects, saturated neon accents, generic software dashboards, and hyperactive micro-interactions. Instead, it draws from warm editorial publishing and understated physical craftsmanship: archival paper tones, ink-like typographic precision, and quiet structural balance.

The visual tone is calm, empathetic, and grounded. Interactions prioritize high readability, low cognitive load, and immediate accessibility. Visual elements do not compete with the communication stream; they recede to let facial expressions, hand signs, speech transcriptions, and synthesized vocal output take center stage.

## Colors

The palette is derived from natural pigment, paper, and botanical tones. All foreground pairings meet WCAG AAA requirements (minimum 7:1 for body copy and 4.5:1 for large display elements) to ensure legibility across lighting conditions and visual acuities.

- **Canvas & Surface Base:** Warm off-white (`#FBF9F5`) serves as the primary canvas, backed by secondary surface card fill (`#F5F2EB`) and tertiary paneling (`#EEE8DF`). These cream and parchment foundations prevent visual glare caused by stark `#FFFFFF` backgrounds.
- **Deep Charcoal Neutral:** Ink charcoal (`#1F2421`) governs primary text, primary borders, and structural icons. Secondary muted ink (`#4A524D`) provides readable support copy.
- **Muted Forest Green (Primary):** Deep woodland green (`#2D5A43`, with `#244835` for active states) anchors primary actions, confirmed transcriptions, and conversational operational states.
- **Soft Terracotta (Secondary):** Baked earth (`#C86D51`) denotes the Signer channel, active camera input frames, and contextual signer annotations, offering an organic counterbalance to forest green without alarming the user.
- **Stone & Sand Dividers:** Fine borders use warm sand (`#E5DFD5`) to build structure without harsh delineations.
- **Semantic Feedback:** Muted ochre (`#A86E20`) for audio interference or signing occlusion warnings, and desaturated crimson (`#9B3B30`) for errors or dropped device links.

## Typography

The typography unites an editorial serif (`Newsreader`) for narrative, introspective, and display elements with a balanced humanist sans-serif (`Plus Jakarta Sans`) for utility, transcription streams, and interactive control.

- **Newsreader (Headlines & Editorial Touchpoints):** Applied to conversation titles, welcome screens, and empty-state reflections. It invokes the calm presence of literature rather than digital urgency. It must always be set in medium weights to avoid thin hairline fractures on lower-resolution screens.
- **Plus Jakarta Sans (Transcriptions, Labels, & Dialog):** Chosen for its humanist geometry, distinct letterforms, open counters, and high legibility at speed. Conversation transcription logs use `body-lg` (18px) to minimize optical fatigue during real-time speech and sign translation.
- **Type Pairing Rules:** Never set interface control labels, form inputs, or conversational transcription bubbles in `Newsreader`. Keep the serif purely for section headers, mode descriptors, and editorial framing.

## Layout & Spacing

The layout utilizes a structured fluid grid optimized for dual-perspective communication. The design adapts across single-user mobile handoffs, face-to-face tablet split views, and wide desktop monitoring screens.

- **Breakpoints:**
  - *Mobile (< 768px):* Single-column vertical stream. Focus shifts between camera sign-recognition viewfinder and text/audio feed via tactile toggles. Margin is `1rem`, gutter is `1.25rem`.
  - *Tablet (768px - 1024px):* Split-stage or face-to-face orientation. Supports a symmetrical dual pane where the signer and speaker have dedicated visual fields. Margin is `2rem`, gutter is `1.5rem`.
  - *Desktop (> 1024px):* 12-column structured view with persistent live feed, communication timeline, and peripheral accessibility control panels. Margin is `3rem`, gutter is `2rem`.
- **Rhythm & Safe Targets:** All actionable elements maintain an absolute minimum touch boundary of 48×48px. Gap rhythms follow an 8-point structural baseline (`space-xs` to `space-xl`) to establish predictable cadence between speech bubbles, camera frames, and audio waveforms.

## Elevation & Depth

This system avoids floating volumetric drop shadows and artificial blurred elevations. Depth is established through **tactile tonal layering and crisp structural borders**.

- **Surface Tiers:**
  - *Base Canvas:* `#FBF9F5` (Foundation backdrop).
  - *Container Tier 1 (Cards, Viewfinders):* `#F5F2EB` bounded by a 1px solid `#E5DFD5` border.
  - *Container Tier 2 (Transcript Bubbles, Active Blocks):* `#FFFFFF` or tinted neutral surfaces rested directly within Tier 1 containers, outlined by `#DFD8CD`.
  - *Overlay Sheets & Dialogs:* `#FBF9F5` bordered with `#1F2421` (1.5px) supported by an ambient, paper-ink diffuse shadow: `0 8px 24px -4px rgba(31, 36, 33, 0.08)`.
- **Tactile Insets:** Input fields and recording states use a subtle 1px inset boundary rather than dark drop shadows, creating the physical sensation of debossed stationery.

## Shapes

The shape system employs roundedness level 2 (0.5rem base) to convey a humane, gentle presence without becoming overly bulbous or child-like.

- **Base Radius (0.5rem / 8px):** Applied to standard action buttons, input fields, control panels, and notification toasts.
- **Large Radius (1rem / 16px):** Reserved for transcription message bubbles, video viewfinder panels, and grouped container cards.
- **Extra Large Radius (1.5rem / 24px):** Used exclusively for conversational modal sheets and mode switcher control wells.
- **Full Pill (`9999px`):** Strictly used for interactive chips, conversational status pills, and toggle indicators.

## Components

### Buttons
- **Primary Action (Forest):** Background `#2D5A43`, text `#FBF9F5`, border 1px solid `#244835`. Hover/focus transitions smoothly to `#244835`. Padding: `0.75rem 1.5rem`. Height: 48px minimum.
- **Secondary Action (Terracotta Outline):** Background `#F5F2EB`, text `#C86D51`, border 1.5px solid `#C86D51`. Used for signer-specific interactions and camera resets.
- **Subtle / Neutral Action:** Background transparent, text `#1F2421`, border 1px solid `#E5DFD5`. Hover produces `#EEE8DF` background.

### Conversation Stream & Timeline Messages
- **Signer Bubble (Visual to Speech):** Left-aligned or right-aligned by mode. Surface `#F5F0E9` with a pronounced 3px solid left accent border in terracotta (`#C86D51`). Text in deep charcoal (`#1F2421`).
- **Speaker Bubble (Speech to Text):** Soft off-white surface (`#FFFFFF`) with a 3px solid left accent border in forest green (`#2D5A43`). Text in deep charcoal (`#1F2421`).
- Both bubbles use 1rem (`rounded-lg`) corner radii, 1rem internal padding, and display unambiguous channel badges ("Signer" / "Speaker").

### Mode Switcher (Sign to Speech vs. Speech to Text)
- A segmented horizontal toggle resting within an enclosed sand container (`#E5DFD5`, 4px padding, `rounded-xl`).
- The active segment lifts forward in `#FBF9F5` with a 1px border (`#D1C9BE`), accompanied by an ink label and an icon indicating directional flow.

### Status Chips & Badges
- Pill-shaped (`rounded-full`), padding `0.25rem 0.75rem`.
- **Live Signing Active:** `#FBF0EB` background, `#984A33` text, terracotta dot indicator (`#C86D51`).
- **Audio Capturing:** `#EDF3EE` background, `#244835` text, forest green pulsing wave icon.
- **Calibrating:** `#F4F0E8` background, `#665B49` text.

### Form Inputs & Textareas
- Surface `#FFFFFF`, border 1px solid `#E5DFD5`, radius `0.5rem`.
- Focus state: Border transitions to `#2D5A43` with a crisp, non-blurry 2px outline in `#2D5A43` (at 20% opacity) with zero offset. Typography set to `body-md` (16px) to prevent iOS auto-zoom triggers.

### Cards & Viewfinders
- **Video Viewfinder:** Container background `#1F2421` with a 1.5px warm border (`#E5DFD5`). Camera guides use subdued terracotta edge brackets to assist signer framing without cluttering the screen.
- **Audio Waveform Card:** Card background `#F5F2EB`, border 1px solid `#E5DFD5`, hosting soft charcoal bars that animate with vocal rhythm.